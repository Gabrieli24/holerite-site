<?php
$db = new SQLite3("db.sqlite");
$db->exec("CREATE TABLE IF NOT EXISTS funcionarios (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, cpf TEXT)");
$db->exec("CREATE TABLE IF NOT EXISTS holerites (id INTEGER PRIMARY KEY AUTOINCREMENT, funcionario_id INTEGER, arquivo TEXT)");
echo "Banco de dados criado!";
?>