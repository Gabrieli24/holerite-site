<?php
session_start();
$id = $_SESSION["funcionario_id"] ?? null;
if (!$id) exit("Acesso negado.");
$db = new SQLite3("db.sqlite");
$stmt = $db->prepare("SELECT arquivo FROM holerites WHERE funcionario_id = ?");
$stmt->bindValue(1, $id, SQLITE3_INTEGER);
$results = $stmt->execute();
echo "<h2>Seus Holerites</h2><ul>";
while ($row = $results->fetchArray()) {
    echo "<li><a href='uploads/{$row['arquivo']}' target='_blank'>{$row['arquivo']}</a></li>";
}
echo "</ul>";
?>