<?php
session_start();
if (!($_SESSION["admin"] ?? false)) exit("Acesso negado.");
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_FILES["arquivo"])) {
    $id = $_POST["funcionario_id"];
    $arquivo = basename($_FILES["arquivo"]["name"]);
    move_uploaded_file($_FILES["arquivo"]["tmp_name"], "uploads/$arquivo");
    $db = new SQLite3("db.sqlite");
    $stmt = $db->prepare("INSERT INTO holerites (funcionario_id, arquivo) VALUES (?, ?)");
    $stmt->bindValue(1, $id, SQLITE3_INTEGER);
    $stmt->bindValue(2, $arquivo, SQLITE3_TEXT);
    $stmt->execute();
    echo "Holerite enviado!";
}
?>
<form method="post" enctype="multipart/form-data">
    ID do funcionário: <input name="funcionario_id" required>
    PDF: <input type="file" name="arquivo" accept="application/pdf" required>
    <button type="submit">Enviar</button>
</form>