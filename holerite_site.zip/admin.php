<?php
session_start();
if ($_POST["senha"] ?? "" === "admin123") {
    $_SESSION["admin"] = true;
    header("Location: painel.php");
    exit;
}
?>
<form method="post">
    Senha de admin: <input type="password" name="senha" required><br>
    <button type="submit">Entrar</button>
</form>