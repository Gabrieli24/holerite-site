<?php
session_start();
if (!($_SESSION["admin"] ?? false)) exit("Acesso negado.");
$db = new SQLite3("db.sqlite");
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = $_POST["nome"];
    $cpf = $_POST["cpf"];
    $db->exec("INSERT INTO funcionarios (nome, cpf) VALUES ('$nome', '$cpf')");
}
$result = $db->query("SELECT * FROM funcionarios");
?>
<h2>Cadastrar Funcionário</h2>
<form method="post">
    Nome: <input name="nome" required>
    CPF: <input name="cpf" required>
    <button type="submit">Salvar</button>
</form>
<h2>Funcionários</h2>
<ul>
<?php while ($row = $result->fetchArray()) {
    echo "<li>{$row['nome']} - {$row['cpf']}</li>";
} ?>
</ul>