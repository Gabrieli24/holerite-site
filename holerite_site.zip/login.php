<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = $_POST["nome"] ?? "";
    $cpf = $_POST["cpf"] ?? "";
    $db = new SQLite3("db.sqlite");
    $stmt = $db->prepare("SELECT id FROM funcionarios WHERE nome = ? AND cpf = ?");
    $stmt->bindValue(1, $nome, SQLITE3_TEXT);
    $stmt->bindValue(2, $cpf, SQLITE3_TEXT);
    $result = $stmt->execute()->fetchArray();
    if ($result) {
        $_SESSION["funcionario_id"] = $result["id"];
        header("Location: holerites.php");
        exit;
    } else {
        $erro = "Nome ou CPF incorretos.";
    }
}
?>
<form method="post">
    Nome: <input name="nome" required><br>
    CPF: <input name="cpf" required><br>
    <button type="submit">Entrar</button>
    <?php if (!empty($erro)) echo "<p style='color:red;'>$erro</p>"; ?>
</form>